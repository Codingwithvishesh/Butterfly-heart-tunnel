# Red Heart Butterfly Tunnel 🦋❤️

An infinite tunnel animation built using Python and Pygame, where butterflies arrange themselves in a 3D heart-shaped formation with glowing effects and particles, completely themed in shades of red.

## Requirements

Ensure you have Python and Pygame installed on your system.

- Python 3.x
- Pygame library

## Installation & Setup

1. Create a folder named `butterfly_heart_tunnel`.
2. Save the python script inside it as `main.py`.
3. Save this file as `README.md`.

## How to Run

Open your terminal or command prompt inside the project folder and run:

```bash
pip install pygame
python main.py